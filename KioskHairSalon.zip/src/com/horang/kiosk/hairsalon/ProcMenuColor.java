package com.horang.kiosk.hairsalon;

import com.horang.kiosk.hairsalon.product.MenuColor;
import com.horang.kiosk.hairsalon.product.Product;
import com.horang.util.Cw;

public class ProcMenuColor {
public static void run() {
		
		for(Product p:KioskOBJ.products) {
			if(p instanceof MenuColor) {
				Cw.wn(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			
			Cw.wn("[1. 뿌리 염색 / 2. 일반 염색 / 3. 디자인 염색 / x. 이전 메뉴로]");
			KioskOBJ.cmd = KioskOBJ.sc.next();
			switch(KioskOBJ.cmd) {
			case "1":
				Cw.wn(KioskOBJ.products.get(3).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(3)));
				break;
			case "2":
				Cw.wn(KioskOBJ.products.get(4).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(4)));
				OptionLength.run();
				break;
			case "3":
				Cw.wn(KioskOBJ.products.get(5).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(5)));
				OptionLength.run();
			case "x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break yy;
			}
		}
	}
}
