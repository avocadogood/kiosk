package com.horang.kiosk.hairsalon;

import java.util.ArrayList;
import java.util.Scanner;

import com.horang.kiosk.hairsalon.product.MenuClinic;
import com.horang.kiosk.hairsalon.product.MenuColor;
import com.horang.kiosk.hairsalon.product.MenuCut;
import com.horang.kiosk.hairsalon.product.MenuDry;
import com.horang.kiosk.hairsalon.product.MenuPerm;
import com.horang.kiosk.hairsalon.product.Product;


public class KioskOBJ {
	public static ArrayList<Order> basket = new ArrayList<>();
	public static ArrayList<Product> products = new ArrayList<>();
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	public static int lengthPrice;
	
	public static void productLoad() {
		products.add(new MenuClinic("앰플", 15000, 0));
		products.add(new MenuClinic("단백질 클리닉", 30000, 0));
		products.add(new MenuClinic("두피 관리", 30000, 0));
		
		products.add(new MenuColor("뿌리 염색", 25000, 0));
		products.add(new MenuColor("일반 염색", 30000, 0));
		products.add(new MenuColor("디자인 염색", 40000, 0));
		
		products.add(new MenuCut("학생 커트", 15000));
		products.add(new MenuCut("성인 커트", 20000));
		products.add(new MenuCut("디자인 커트", 30000));
		
		products.add(new MenuDry("샴푸", 10000));
		products.add(new MenuDry("드라이", 25000));
		
		products.add(new MenuPerm("뿌리펌", 25000, 0));
		products.add(new MenuPerm("셋팅펌", 40000, 0));
		products.add(new MenuPerm("볼륨매직", 30000, 0));
		
	}
	
}
