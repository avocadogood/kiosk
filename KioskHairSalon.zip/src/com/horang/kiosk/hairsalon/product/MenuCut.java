package com.horang.kiosk.hairsalon.product;

public class MenuCut extends Product {
	
	
	public MenuCut (String name, int price) {
		super(name, price);
	}
}
