package com.horang.kiosk.hairsalon.product;

public class Product {
	public String name;
	public int price;
	
	public Product(String name, int price) {
		this.name = name;
		this.price = price;
	}
	
	public void productInfo() {
		System.out.println(name+"의 가격은 "+price+"원입니다.");
	}

}
