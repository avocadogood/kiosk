package com.horang.kiosk.hairsalon.product;

public class MenuDry extends Product {
	
	
	public MenuDry (String name, int price) {
		super(name, price);
	}
}
