package com.horang.kiosk.hairsalon.product;

public class MenuPerm extends Product{
	public int hairLength;
	
	public MenuPerm (String name, int price, int hairLength) {
		super(name, price);
		this.hairLength = hairLength;	
	}
	@Override
    public void productInfo() {
        super.productInfo();
        System.out.println("기장 30cm 이상은 15,000원이 추가됩니다.");
    }
}
