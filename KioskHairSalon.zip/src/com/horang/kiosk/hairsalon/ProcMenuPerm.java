package com.horang.kiosk.hairsalon;

import com.horang.kiosk.hairsalon.product.MenuPerm;
import com.horang.kiosk.hairsalon.product.Product;
import com.horang.util.Cw;

public class ProcMenuPerm {
public static void run() {
		
		for(Product p:KioskOBJ.products) {
			if(p instanceof MenuPerm) {
				Cw.wn(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			
			Cw.wn("[1. 뿌리펌 / 2. 셋팅펌 / 3. 볼륨매직 / x. 이전 메뉴로]");
			KioskOBJ.cmd = KioskOBJ.sc.next();
			switch(KioskOBJ.cmd) {
			case "1":
				Cw.wn(KioskOBJ.products.get(11).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(11)));
				break;
			case "2":
				Cw.wn(KioskOBJ.products.get(12).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(12)));
				OptionLength.run();
				break;
			case "3":
				Cw.wn(KioskOBJ.products.get(13).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(13)));
				OptionLength.run();
			case "x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break yy;
			}
		}
	}
}
