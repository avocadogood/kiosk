package com.horang.kiosk.hairsalon;

import com.horang.util.Cw;

public class Kiosk {
	void run() {
		KioskOBJ.productLoad();
		Disp.title();
		xx:while(true) {
			Cw.wn("1. 커트 / 2. 염색 / 3. 펌 / 4. 클리닉 / 5. 드라이 / e. 종료]: ");
			KioskOBJ.cmd = KioskOBJ.sc.next();
			switch(KioskOBJ.cmd) {
			case "1":
				ProcMenuCut.run();
				break;
			case "2":
				ProcMenuColor.run();
				break;
			case "3":
				ProcMenuPerm.run();
				break;
			case "4":
				ProcMenuClinic.run();
				break;
			case "5":
				ProcMenuDry.run();
				break;
			case "e":
				Cw.wn("총 주문 수량: "+KioskOBJ.basket.size());
				int sum = 0;
				for(Order o:KioskOBJ.basket) {
					sum = sum + o.selectedProduct.price + KioskOBJ.lengthPrice;
				}
				Cw.wn("계산하실 금액은 "+sum+"원입니다.");
				Cw.wn("(기장 추가 " + KioskOBJ.lengthPrice + "원)");
				
				Cw.wn("🐯🐯🐯🐯🐯🐯");
				for(Order o:KioskOBJ.basket) {
					Cw.wn(o.selectedProduct.name);
				}
				Cw.wn("🐯🐯🐯🐯🐯🐯");
				Cw.wn("주문을 종료합니다.");
				break xx;
			}
		}		
	}
}