package com.horang.kiosk.hairsalon;

import com.horang.kiosk.hairsalon.product.Product;

public class Order {
	public Product selectedProduct;
	public int optionLength = 0;

	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}

	public Order(Product selectedProduct, int optionLength) {
		this.selectedProduct = selectedProduct;
		this.optionLength = optionLength;
	}
}
