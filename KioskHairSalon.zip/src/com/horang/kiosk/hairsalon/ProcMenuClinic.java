package com.horang.kiosk.hairsalon;

import com.horang.kiosk.hairsalon.product.MenuClinic;
import com.horang.kiosk.hairsalon.product.Product;
import com.horang.util.Cw;

public class ProcMenuClinic {
public static void run() {
		
		for(Product p:KioskOBJ.products) {
			if(p instanceof MenuClinic) {
				Cw.wn(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			
			Cw.wn("[1. 앰플 / 2. 단백질 클리닉 / 3. 두피 관리 / x. 이전 메뉴로]");
			KioskOBJ.cmd = KioskOBJ.sc.next();
			switch(KioskOBJ.cmd) {
			case "1":
				Cw.wn(KioskOBJ.products.get(0).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(0)));
				OptionLength.run();
				break;
			case "2":
				Cw.wn(KioskOBJ.products.get(1).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(1)));
				OptionLength.run();
				break;
			case "3":
				Cw.wn(KioskOBJ.products.get(2).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(2)));
				OptionLength.run();
			case "x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break yy;
			}
		}
	}
}
