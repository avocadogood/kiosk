package com.horang.kiosk.hairsalon;

import com.horang.util.Cw;
import com.horang.kiosk.hairsalon.KioskOBJ;
import com.horang.kiosk.hairsalon.Order;

public class OptionLength {
	
	public static int optionLength = 15000;
	
	public static void run() {
		loop:while(true) {
			Cw.wn("[1. 기장 추가 필요 (15,000) / 2. 기장 추가 안 함");
			KioskOBJ.cmd = KioskOBJ.sc.next();
			switch(KioskOBJ.cmd) {
			case "1":
				Cw.wn("기장 추가를 선택하셨습니다.");
				KioskOBJ.lengthPrice += optionLength;
				break loop;
			case "2":
				Cw.wn("이전 메뉴로 돌아갑니다.");
				break loop;
				
				}
			}
		}
	}

