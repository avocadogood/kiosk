package com.horang.kiosk.hairsalon;

import com.horang.kiosk.hairsalon.product.MenuDry;
import com.horang.kiosk.hairsalon.product.Product;
import com.horang.util.Cw;

public class ProcMenuDry {
public static void run() {
		
		for(Product p:KioskOBJ.products) {
			if(p instanceof MenuDry) {
				Cw.wn(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			
			Cw.wn("[1. 샴푸 / 2. 드라이 / x. 이전 메뉴로]");
			KioskOBJ.cmd = KioskOBJ.sc.next();
			switch(KioskOBJ.cmd) {
			case "1":
				Cw.wn(KioskOBJ.products.get(9).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(9)));
				break;
			case "2":
				Cw.wn(KioskOBJ.products.get(10).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(10)));
				break;
			case "x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break yy;
			}
		}
	}
}
