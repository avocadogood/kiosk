package com.horang.kiosk.hairsalon;
import com.horang.util.Cw;

public class Disp {
	final static String DOT = "🐯";
	final static int DOT_COUNT = 18;
	public static void line() {
		for(int i=0;i<DOT_COUNT;i++) {
			Cw.w(DOT);
		}
		Cw.wn();
	}
	
	public static void dot(int n) {
		for(int i=0;i<n;i++) {
			Cw.w(DOT);
		}
	}
	
	public static void title() {
		line();
		dot(6);
		Cw.w(" \\ 호랑이 묭실 / ");
		dot(6);
		Cw.wn();
		line();
	}
	
}
