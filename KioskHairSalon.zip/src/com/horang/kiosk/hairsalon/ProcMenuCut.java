package com.horang.kiosk.hairsalon;

import com.horang.kiosk.hairsalon.product.MenuCut;
import com.horang.kiosk.hairsalon.product.Product;
import com.horang.util.Cw;

public class ProcMenuCut {
public static void run() {
		
		for(Product p:KioskOBJ.products) {
			if(p instanceof MenuCut) {
				Cw.wn(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			
			Cw.wn("[1. 학생 커트 / 2. 성인 커트 / 3. 디자인 커트 / x. 이전 메뉴로]");
			KioskOBJ.cmd = KioskOBJ.sc.next();
			switch(KioskOBJ.cmd) {
			case "1":
				Cw.wn(KioskOBJ.products.get(6).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(6)));
				break;
			case "2":
				Cw.wn(KioskOBJ.products.get(7).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(7)));
				break;
			case "3":
				Cw.wn(KioskOBJ.products.get(8).name+" 선택");
				KioskOBJ.basket.add(new Order(KioskOBJ.products.get(8)));
				break;
			case "x":
				Cw.wn("이전 메뉴로 이동합니다.");
				break yy;
			}
		}
	}
}
